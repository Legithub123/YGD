import cx_Freeze

executables = [cx_Freeze.Executable("YGD code.py")]

cx_Freeze.setup(
    name = 'YGD',
    options = {'build_exe': {'packages':['pygame'],
                             'include_files':['background.png', 'devil.png','dog.png', 'double.png', 'flying.png', 'ghost.png', 'Music.mp3', 'swordman_hitting_left.png','swordman_hitting_right.png', 'swordman_normal_left.png','swordman_normal_right.png']}},
    executables = executables
    )
